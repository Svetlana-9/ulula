import Avatar from "@mui/material/Avatar";

export default function DialogInList(img) {
  return (
    <div>
      <Avatar  src={img} sx={{ width: 70, height: 70 }} />
    </div>
  );
}
