import  ButtonGroups  from './ButtonGroups/ButtonGroups';
import DialogInList from './DialogInList/DialogInList';
import {contacts} from '../../emulator';

export default function ListWithDialogs () {
  return (
    <div>
    <ButtonGroups/>
    <DialogInList img = {contacts[0].avatar}/>
    </div>
  )
}