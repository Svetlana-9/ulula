import Autocomplete from "@mui/material/Autocomplete";
import TextField from "@mui/material/TextField";
import emulator from "../../../emulator"

export default function DialogsSearch() {
  return (
    <Autocomplete
      // disablePortal
      id="combo-box-demo"
      options={emulator.listContacts()}
      sx={{ width: 300}}
      renderInput={(contacts) => <TextField {...contacts} label="Поиск..." />}
    />
  );
}

